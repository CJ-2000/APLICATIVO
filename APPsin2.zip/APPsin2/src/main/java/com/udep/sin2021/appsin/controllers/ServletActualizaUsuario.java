// Capa Controllers: Captura parámetros y actualiza: archivo local y/o registro en la base de datos
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import static com.udep.sin2021.appsin.beans.Global.carpeta_Principal;
import static com.udep.sin2021.appsin.beans.Global.ruta_avatar;
import com.udep.sin2021.appsin.services.UsuarioServices;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig //Permite gestionar la carga de archivos a través de un servlet
public class ServletActualizaUsuario extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        request.setCharacterEncoding("UTF-8");

        // Extrae parámetros del formulario predecesor
        String dni = request.getParameter("DNI"); //Parámetro dni de la persona que se está registrando
        String idrol = request.getParameter("idrol"); //Parámetro Rol de usuario
        String usuario = request.getParameter("usuario"); //Parámetro nickname de usuario
        String clave = request.getParameter("clave"); //Parámetro clave
        String nombres = request.getParameter("nombres"); //Parámetro nombres
        String apellidos = request.getParameter("apellidos"); //Parámetro apellidos
        String email = request.getParameter("email"); //Parámetro email
        String telefono = request.getParameter("telefono"); //Parámetro teléfono
        String emergencia = request.getParameter("emergencia");//Parámetro teléfono de emergencia

        //Creo nueva instancia UsuarioServices
        UsuarioServices us = new UsuarioServices();
        int modo;
        int rpta_B;

        try (PrintWriter out = response.getWriter()) { // Permite crear y escribir archivos en Java

            if (request.getPart("fileB").getSize() > 0) {
                //Hay un archivo foto subido
                modo = 1;

                Part filePart = request.getPart("fileB");  //Parámetro foto (el mismo que se sube al formulario))
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // Arreglo 'MSIE' para extraer el nombre del archivo con su extensión. Ejemplo: "foto.png"
                String extension = fileName.substring(fileName.lastIndexOf(".")); //Devuelve el formato en texto: ejemplo ".png"

                File file_antiguo = new File(carpeta_Principal + ruta_avatar, usuario + extension); //Se almacena el archivo que se va a borrar
                response.setContentType("text/html;charset=GBK"); //Modifico salida del contenido
                file_antiguo.delete(); //Elimina el archivo

                File file = new File(carpeta_Principal + ruta_avatar, usuario + extension); //Se crea una copia del archivo que se sube
                if (!file.isDirectory()) {
                    try (InputStream fileContent = filePart.getInputStream()) {

                        //Llama al servicio ActualizarUsuario y realiza la actualización
                        rpta_B = us.ActualizarUsuario(modo, dni, nombres, apellidos, usuario, clave, email, telefono, emergencia, idrol, ruta_avatar + usuario + extension);

                        if (rpta_B == 0) { //Hubo un error en la base de datos
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('Error. No se pudo registrar');");
                            out.println("location='vistas/dashboard.jsp';");
                            out.println("</script>");
                        } else {
                            Files.copy(fileContent, file.toPath()); //Copia la foto a la locación destino

                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('El usuario se ha actualizado correctamente');");
                            out.println("location='vistas/dashboard.jsp';");
                            out.println("</script>");
                        }

                    } catch (Exception e) {
                        System.out.println("Hubo un problema en el nivel InputStream : " + e);
                    }

                } else {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Error Inesperado. No se ha encontrado la foto'); location='vistas/dashboard.jsp'; ");
                    out.println("</script>");
                }

            }
            if (request.getPart("fileB").getSize() <= 0) {
                //No hay un archivo foto subido
                modo = 0;

                //Llama al servicio ActualizarUsuario y realiza la actualización
                rpta_B = us.ActualizarUsuario(modo, dni, nombres, apellidos, usuario, clave, email, telefono, emergencia, idrol, null);

                if (rpta_B == 0) { //Hubo un error en la base de datos
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Error. No se pudo registrar');");
                    out.println("location='vistas/dashboard.jsp';");
                    out.println("</script>");
                } else {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('El usuario se ha actualizado correctamente');");
                    out.println("location='vistas/dashboard.jsp';");
                    out.println("</script>");
                }

            }

        } catch (Exception e) {
            System.out.println("Hubo un problema en el nivel PrintWriter : " + e);
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ServletRegistraUsuario.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ServletRegistraUsuario.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
