package com.udep.sin2021.appsin.beans;

// Clase guarda parámetros
public class Global {
    
    //Parámetros sobre las carpetas
    public static String carpeta_Principal = "c:/Aplicativo"; //Carpeta principal del aplicativo
    public static  String ruta_documentos = carpeta_Principal + "/documentos/"; //Subcarpeta nivel 1 : Para documentos
    public static  String ruta_img = carpeta_Principal+ "/img/"; //Subcarpeta nivel 1 : Para imágenes e íconos
    
    //Parámetros sobre la base de datos
    public static String host = "appweb2021-mysqldbserver2.mysql.database.azure.com"; 
    public static String puerto = "3306";
    public static String usuario = "lchignej@appweb2021-mysqldbserver2"; 
    public static String password = "2021SIN!"; 
    public static String bd = "bdappsin"; 
    public static String url = "jdbc:mysql://" + host + ":"+puerto+"/"+ bd +"?user=" + usuario + "&password=" + password;

    //Parámetros especiales
    public static String ruta_avatar = "/img/avatars/"; // Especifica la ruta para almacenar íconos de avatars
    
}

