// Capa Controllers: Captura parámetros y adiciona: archivo local y registro en la base de datos
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import com.udep.sin2021.appsin.dao.ConectaBD;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;
import javafx.application.Application;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.util.FileResolver;

public class ServletGeneraReporte extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, JRException, SQLException, ClassNotFoundException {

        String source = request.getParameter("source"); // Parámetro tipo de fuente : documentos o usuarios
        String nombre_archivo_jasper;
        String nombre;

        if (null == source) {
            nombre = "";
            nombre_archivo_jasper = "";
        } else //De acuerdo al tipo de fuente, se asigna el nombre de la salida del documento y el plantilla del reporte que se usará
        switch (source) {
            case "documentos":
                nombre = "Reporte_documentos.pdf";
                nombre_archivo_jasper = "reportes/documentos.jrxml";
                break;
            case "usuarios":
                nombre = "Reporte_usuarios.pdf";
                nombre_archivo_jasper = "reportes/usuarios.jrxml";
                break;
            default:
                nombre = "Reporte,pdf";
                nombre_archivo_jasper = "";
                break;
        }

        //Usar archivos .jrxml respecto al .jasper (ya compilado) es más ventajoso
        //Se identifica el archivo jrxml
        File theFile = new File(request.getRealPath(nombre_archivo_jasper));
        //Se carga el archivo
        JasperDesign jasperDesign = JRXmlLoader.load(theFile);
        //Realiza la conexión a la BD
        Connection con = ConectaBD.initializeDatabase();
        //Se compila el archivo a .jasper
        JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
        //Se llena el reporte (se ejecuta la consulta)
        JasperPrint print = new JasperPrint();
        //Imprime el reporte generado "jasperReport", con "null" parametros y conexión a BD "con"
        print = JasperFillManager.fillReport(jasperReport, null, con);

        byte[] pdfBytes = JasperExportManager.exportReportToPdf(print);
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline;filename=\"" + nombre + "\"");
        response.getOutputStream().write(pdfBytes);
        response.flushBuffer();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (JRException | SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletGeneraReporte.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (JRException | SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletGeneraReporte.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
