// Capa Controllers: Servlet enlaza con archivos existentes para mostrar en documentos HTML o JSP
// (Modificado de https://balusc.omnifaces.org/2007/07/fileservlet.html)
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import static com.udep.sin2021.appsin.beans.Global.carpeta_Principal;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class fileServlet extends HttpServlet {

    private static final int DEFAULT_BUFFER_SIZE = 10240; // Constante 10KB.
    private String filePath; // Propiedad

    @Override // Acciones
    public void init() throws ServletException {
        this.filePath = carpeta_Principal; // Define la ruta base
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String requestedFile = request.getPathInfo(); // Obtiene el archivo solicitado por información de ruta de acceso.

        if (requestedFile == null) { // Comprueba si el archivo se proporciona realmente al URI de la solicitud.
            // En caso el archivo no se proporciona al URI de solicitud lanza un error
            // Envía 404, o muestre la página predeterminada/de advertencia
            response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
            return;
        }

        File file = new File(filePath, URLDecoder.decode(requestedFile, "UTF-8")); // Descodifica el nombre de archivo

        if (!file.exists()) { // Comprueba si el archivo realmente existe
            // En caso el archivo parece no existir
            // Envía 404, o muestre la página predeterminada/de advertencia
            response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
            return;
        }

        // Obtiene el tipo de contenido por nombre de archivo
        String contentType = getServletContext().getMimeType(file.getName());

        // Se le da como tipo de contenido el valor predeterminado
        // NOTA: Para agregar nuevos tipos de contenido, agregue una nueva entrada mime-mapping en web.xml.
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        // Respuesta del servlet
        response.reset();
        response.setBufferSize(DEFAULT_BUFFER_SIZE);
        response.setContentType(contentType);
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");

        // Prepara secuencias.
        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            // Abre streams
            input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);
            output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

            // Escriba el contenido del archivo en la respuesta
            byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
        } finally {
            // Cierra streams
            close(output);
            close(input);
        }
    }

    // Ayudantes 
    private static void close(Closeable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (IOException e) {
                // Imprime la excepción
                e.printStackTrace();
            }
        }
    }
}
