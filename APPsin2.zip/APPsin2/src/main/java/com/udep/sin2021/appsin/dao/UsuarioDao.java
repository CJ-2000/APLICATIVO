/* Capa Persistencia o DAO:*/
// Toma la BD y crea un objeto

package com.udep.sin2021.appsin.dao;

import com.udep.sin2021.appsin.beans.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDao {
    //Esta clase contiene métodos que devuelven entero, lista o algún otro tipo de dato
    
    public int buscarUsuario(String usuario, String clave, Usuario u1) throws ClassNotFoundException, SQLException{    
        //Este método se usa para validar al usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1

        try (Connection con = ConectaBD.initializeDatabase()) {
            //Statement stmt =con.createStatement();
            PreparedStatement pstmt;
            ResultSet rs;
            
            pstmt = con.prepareStatement("SELECT * FROM usuario WHERE usuario = ? AND clave = ?"); //Crea un objeto PreparedStatement
            pstmt.setString(1, usuario); //Asigna valor al parámetro usuario
            pstmt.setString(2, clave); //Asigna valor al parámetro clave
            
            //rs= pstmt.executeQuery(consulta);
            rs = pstmt.executeQuery();
                
            if (!rs.next()) {
                //No existe coincidencia
                return 0;
            } else{
                //Guarda los datos de la consulta dentro de los atributos de Usuario
                u1.setDni(rs.getInt("dni"));
                u1.setNombres(rs.getString("nombres"));
                u1.setApellidos(rs.getString("apellidos"));
                u1.setUsuario(rs.getString("usuario"));
                u1.setClave(rs.getString("clave"));
                u1.setEmail(rs.getString("email"));
                u1.setTelefono(rs.getInt("telefono"));
                u1.setEmergencia(rs.getInt("emergencia"));
                u1.setIdrol(rs.getString("idrol"));
                u1.setRutaFoto(rs.getString("rutaFoto"));
                
                con.close(); // Cierra la conexión de la BD
                rs.close(); // Cierra el ResultSet
                pstmt.close(); // Cierra el PreparedStatement
                return 1;
            }    
            
        } catch(SQLException error) {
           return 404;     
        }
    }
    
    public int EliminaFoto(String dni) throws ClassNotFoundException, SQLException{    
        //Este método se usa para validar al usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1
        try (Connection con = ConectaBD.initializeDatabase()) { //Conecta con la base de datos

            PreparedStatement pstmt;
            ResultSet rs;            
            
            //Statement stmt =con.createStatement(); // Crea un objeto Statement
            String consulta = "DELETE FROM usuario WHERE DNI = ?"; 
            pstmt = con.prepareStatement(consulta); //Crea un objeto PreparedStatement
            pstmt.setString(1, dni); //Asigna valor al parámetro clave
            
            rs= pstmt.executeQuery();

            if (!rs.next()) { 
                //No hubo respuesta
                return 0;
            } else{ 
                //Se logró eliminar
                // Cierra la conexión de la BD
                con.close();                
                return 1;
            }    
        } catch(SQLException error) { //Si no conecta la base de datos
           return 404;     
        }
    }

    public int ActualizarUsuario(int modo, String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws SQLException, ClassNotFoundException {
        //Este método se usa para actualizar datos en la BD, de un usuario
        //Retorna valor int: 0 o 1
        
        PreparedStatement pstmt;
            
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        //Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
        String consulta; //modo 0 no modifica la ruta de foto, modo 1 sí modifica la ruta de foto
        
        if (modo == 0) {
            /*consulta = "UPDATE usuario SET "
                    + "nombres = '" + nombres + "', "
                    + "apellidos = '" + apellidos + "', "
                    + "usuario = '" + usuario + "', "
                    + "clave = '" + clave + "', "
                    + "email = '" + email + "', "
                    + "telefono = '" + telefono + "', "
                    + "emergencia = '" + emergencia + "', "
                    + "idrol = '" + idrol + "'"
                    + "WHERE dni = '" + dni + "'";*/
            
            consulta = "UPDATE usuario SET nombres = ?, apellidos = ?, usuario = ?, clave = ?, email = ?, telefono = ?, emergencia = ?, idrol = ? WHERE dni = ?";
            pstmt = con.prepareStatement(consulta); //Crea un objeto PreparedStatement
            pstmt.setString(1, nombres); //Asigna valor al parámetro
            pstmt.setString(2, apellidos); //Asigna valor al parámetro
            pstmt.setString(3, usuario); //Asigna valor al parámetro
            pstmt.setString(4, clave); //Asigna valor al parámetro
            pstmt.setString(5, email); //Asigna valor al parámetro
            pstmt.setString(6, telefono); //Asigna valor al parámetro
            pstmt.setString(7, emergencia); //Asigna valor al parámetro
            pstmt.setString(8, idrol); //Asigna valor al parámetro
            pstmt.setString(9, dni); //Asigna valor al parámetro
            
        } else {
            /*consulta = "UPDATE usuario SET "
                    + "nombres = '" + nombres + "', "
                    + "apellidos = '" + apellidos + "', "
                    + "usuario = '" + usuario + "', "
                    + "clave = '" + clave + "', "
                    + "email = '" + email + "', "
                    + "telefono = '" + telefono + "', "
                    + "emergencia = '" + emergencia + "', "
                    + "idrol = '" + idrol + "', "
                    + "rutaFoto = '" + rutaFoto + "'"
                    + "WHERE dni = '" + dni + "'";*/
            consulta = "UPDATE usuario SET nombres = ?, apellidos = ?, usuario = ?, clave = ?, email = ?, telefono = ?, emergencia = ?, idrol = ? , rutaFoto = ? WHERE dni = ?";
            pstmt = con.prepareStatement(consulta); //Crea un objeto PreparedStatement
            pstmt.setString(1, nombres); //Asigna valor al parámetro
            pstmt.setString(2, apellidos); //Asigna valor al parámetro
            pstmt.setString(3, usuario); //Asigna valor al parámetro
            pstmt.setString(4, clave); //Asigna valor al parámetro
            pstmt.setString(5, email); //Asigna valor al parámetro
            pstmt.setString(6, telefono); //Asigna valor al parámetro
            pstmt.setString(7, emergencia); //Asigna valor al parámetro
            pstmt.setString(8, idrol); //Asigna valor al parámetro
            pstmt.setString(9, rutaFoto); //Asigna valor al parámetro
            pstmt.setString(10, dni); //Asigna valor al parámetro

        }

        int filas = pstmt.executeUpdate();
        if (filas > 0) { //Se logró eliminar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }      
    
    public int RegistraUsuario(String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws ClassNotFoundException, SQLException{    
        //Este método se usa para registrar un usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        //Statement stmt =con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
        PreparedStatement pstmt;
        String consulta;

        /*consulta = "INSERT INTO usuario "
                + "(DNI,nombres,apellidos,usuario,clave,email,telefono,emergencia,idrol,rutaFoto) VALUES "
                + "('" + dni + "'"
                + ",'" + nombres + "'" 
                + ",'" + apellidos + "'" 
                + ",'" + usuario + "'" 
                + ",'" + clave + "'" 
                + ",'" + email + "'" 
                + ",'" + telefono + "'"
                + ",'" + emergencia + "'"
                + ",'" + idrol + "'" 
                + ",'" + rutaFoto + "'" 
                + ")";*/
        
        consulta = "INSERT INTO usuario(DNI,nombres,apellidos,usuario,clave,email,telefono,emergencia,idrol,rutaFoto) VALUES (?,?,?,?,?,?,?,?,?,?) ";
        pstmt = con.prepareStatement(consulta); //Crea un objeto PreparedStatement
        pstmt.setString(1, dni); //Asigna valor al parámetro
        pstmt.setString(2, nombres); //Asigna valor al parámetro
        pstmt.setString(3, apellidos); //Asigna valor al parámetro
        pstmt.setString(4, usuario); //Asigna valor al parámetro
        pstmt.setString(5, clave); //Asigna valor al parámetro
        pstmt.setString(6, email); //Asigna valor al parámetro
        pstmt.setString(7, telefono); //Asigna valor al parámetro
        pstmt.setString(8, emergencia); //Asigna valor al parámetro
        pstmt.setString(9, idrol); //Asigna valor al parámetro
        pstmt.setString(10, rutaFoto); //Asigna valor al parámetro
        
        int filas = pstmt.executeUpdate();
        if (filas > 0) { //Se logró insertar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }
    
    
}
