/* Capa bean :*/
//  Lleva y trae información, sin otra lógica*/
//Atributos privados no pueden modificarse directamente, se debe usar métodos accesores como Refactor - Encapsulate Fields

package com.udep.sin2021.appsin.beans;

public class Usuario {

    private int dni;
    private String nombres;
    private String apellidos;
    private String usuario;
    private String clave;
    private String email;
    private int telefono;
    private int emergencia;
    private String idrol;
    private String rutaFoto;
    
    /**
     * @return the dni
     */
    public int getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(int dni) {
        this.dni = dni;
    }

    /**
     * @return the nombres
     */
    public String getNombres() {
        return nombres;
    }

    /**
     * @param nombres the nombres to set
     */
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the clave
     */
    public String getClave() {
        return clave;
    }

    /**
     * @param clave the clave to set
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the telefono
     */
    public int getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the emergencia
     */
    public int getEmergencia() {
        return emergencia;
    }

    /**
     * @param emergencia the emergencia to set
     */
    public void setEmergencia(int emergencia) {
        this.emergencia = emergencia;
    }

    /**
     * @return the idrol
     */
    public String getIdrol() {
        return idrol;
    }

    /**
     * @param idrol the idrol to set
     */
    public void setIdrol(String idrol) {
        this.idrol = idrol;
    }

    /**
     * @return the rutaFoto
     */
    public String getRutaFoto() {
        return rutaFoto;
    }

    /**
     * @param rutaFoto the rutaFoto to set
     */
    public void setRutaFoto(String rutaFoto) {
        this.rutaFoto = rutaFoto;
    }


    
    
    
}
