// Capa Controllers : Captura parámetros y elimina: archivo local y registro en la base de datos
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import static com.udep.sin2021.appsin.beans.Global.ruta_documentos;
import com.udep.sin2021.appsin.services.DocumentoServices;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDeleteDocumento extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {

        // Extrae parámetro "nombre" del enlace predecesor
        //Ejemplo: "PC-08 Taller de Servicios-MS V.08.pdf"
        String nombre = new String(request.getParameter("nombre").getBytes("iso8859-1"), "gbk");

        //ID seguimiento que se usará para la consulta delete
        String idSeguimiento = request.getParameter("idSeguimiento");

        // Ruta de la carpeta destino donde se va a buscar el archivo
        String ruta = ruta_documentos + request.getParameter("ruta");

        // Se declara el archivo que se va a eliminar
        File file = new File(ruta + nombre);
        response.setContentType("text/html;charset=GBK");

        try (PrintWriter out = response.getWriter()) { // Permite crear y escribir archivos en Java
            if (!file.isDirectory()) {

                // Crea un nuevo DocumentoServices
                DocumentoServices ds = new DocumentoServices();
                int rpta = ds.EliminaDocumento(idSeguimiento);
                if (rpta == 0) {
                    /*Lanza una alerta en javascript*/
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Hay un error con la base de datos. No se pudo eliminar');");
                    out.println("location='vistas/registrodoc.jsp';");
                    out.println("</script>");
                } else {
                    file.delete(); //Elimina el archivo

                    /*Lanza una alerta en javascript*/
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Documento " + nombre + " eliminado'); location='vistas/dashboard.jsp'; ");
                    out.println("</script>");
                }
            } else {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Error Inesperado. No se encontró el documento'); location='vistas/dashboard.jsp'; ");
                out.println("</script>");
            }
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletDeleteDocumento.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletDeleteDocumento.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
