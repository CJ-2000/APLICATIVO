// Capa Controllers: Captura parámetros y adiciona: archivo local y registro en la base de datos
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import static com.udep.sin2021.appsin.beans.Global.ruta_documentos;
import com.udep.sin2021.appsin.services.DocumentoServices;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.apache.commons.lang3.StringUtils;
import static org.apache.commons.lang3.StringUtils.right;

@MultipartConfig //Permite gestionar la carga de archivos a través de un servlet
public class ServletUploadDocumento extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException, ParseException {
        request.setCharacterEncoding("UTF-8");

        //Recoge parámetros del form de la página precedente
        String codigo = request.getParameter("codigo"); //Parámetro código
        String version = request.getParameter("version"); //Parámetro versión
        int dni = Integer.parseInt(request.getParameter("DNI")); //Parámetro dni de la persona que sube documento

        DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String fecha = sdf.format(new Date()); //Convierte la fecha a string

        int idEstado = Integer.parseInt(request.getParameter("idEstado")); //Parámetro Estado de documento
        String idCarpetaRaiz = request.getParameter("idCarpetaRaiz"); //Parámetro Carpeta Raíz de documento
        String idArea = request.getParameter("idArea"); //Parámetro Área
        String idUnidad = request.getParameter("idUnidad"); //Parámetro Unidad
        String idTipo = request.getParameter("idTipo");  //Parámetro Tipo

        //Crea nueva instancia DocumentoServices
        DocumentoServices ds = new DocumentoServices();
        String nombreDocumento = StringUtils.stripAccents(ds.NombreCarpeta_String("nombre", "documento", "codigo", codigo)); //Nombre del documento
        String nombreEstado = ds.NombreCarpeta_Integer("nombreEstado", "estado", "idEstado", idEstado); //Nombre del Estado del documento
        String nombreCarpeta = StringUtils.stripAccents(ds.NombreCarpeta_String("nombreCarpeta", "carpeta_raiz", "idCarpetaRaiz", idCarpetaRaiz)); //Nombre de la Carpeta raíz
        String nombreArea = ds.NombreCarpeta_String("nombreArea", "area", "idArea", idArea); //Nombre del área 
        String nombreUnidad = ds.NombreCarpeta_String("nombreUnidad", "unidad_negocio", "idUnidad", idUnidad); //Nombre de la unidad
        String nombreTipo = ds.NombreCarpeta_String("nombreTipo", "tipo_documento", "idTipo", idTipo); //Nombre del tipo de documento

        Part filePart = request.getPart("fileA"); //Parámetro documento (el mismo que se sube al formulario)
        // Permite extraer el nombre del archivo con su extensión. Ejemplo: "Documento.docx"
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

        String idformato; //Sirve para colocar ícono y extensión al archivo, en la aplicación

        switch (right(fileName, 4)) { //Lee las últimas 4 cifras del archivo para conocer su extensión
            case "xlsx": {
                idformato = "xlsx";
                break;
            } //es un archivo Excel
            case ".pdf": {
                idformato = "pdf";
                break;
            } //es un archivo Pdf
            case "pptx": {
                idformato = "pptx";
                break;
            } //es un archivo Ppt
            case "docx": {
                idformato = "docx";
                break;
            } ///es un archivo Word
            default:
                idformato = "blank";
                break;
        }

        // Ruta para almacenar los archivos cargados
        String ruta_destino = ruta_documentos + nombreEstado + "/" + nombreCarpeta + "/" + nombreArea + "/" + nombreUnidad + "/" + nombreTipo;
        String nombre_archivo = codigo + " " + nombreDocumento + " V." + version + "." + idformato;

        //Se creará una copia del archivo que se sube
        File file = new File(ruta_destino, nombre_archivo);

        /*Se intenta ingresar el contenido y se insertan datos a la BD*/
        try (InputStream fileContent = filePart.getInputStream()) {
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) { // Permite crear y escribir archivos en Java
                // Se utiliza el método para Registrar Documento
                int rpta = ds.RegistraDocumento(codigo, idEstado, version, dni, fecha, idCarpetaRaiz, idArea, idUnidad, idTipo, idformato);
                if (rpta == 0) {
                    /* retorna respuesta */
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Error. No se pudo registrar');");
                    out.println("location='vistas/registrodoc.jsp';");
                    out.println("</script>");
                } else {
                    Files.copy(fileContent, file.toPath()); //Copia los archivos a la locación destino
                    /*Lanza una alerta en javascript*/
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('El archivo se subió correctamente');");
                    out.println("location='vistas/dashboard.jsp';");
                    out.println("</script>");
                }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException | ParseException ex) {
            Logger.getLogger(ServletUploadDocumento.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException | ParseException ex) {
            Logger.getLogger(ServletUploadDocumento.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect(request.getContextPath() + "/vistas/404.jsp");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
