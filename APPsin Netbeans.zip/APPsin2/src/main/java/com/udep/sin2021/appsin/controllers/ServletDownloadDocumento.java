// Capa Controllers : Captura parámetros y DEscarga documento
package com.udep.sin2021.appsin.controllers;

// Importa clases necesarias
import static com.udep.sin2021.appsin.beans.Global.ruta_documentos;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDownloadDocumento extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String nombre = request.getParameter("nombre"); // Extrae parámetro "nombre" del formulario predecesor.Ejemplo: "PC-08 Taller de Servicios-MS V.08.pdf"
        String ruta = ruta_documentos + request.getParameter("ruta"); // Ruta de la carpeta destino donde se va a buscar el archivo

        // Se le da como tipo de contenido el valor predeterminado
        response.setContentType("application/octet-stream");

        // Solo guarda el archivo, no lo va a mostrar
        response.setHeader("Content-Disposition", "attachment; filename=\"" + nombre + "\"");

        // Se descarga el archivo
        File f = new File(ruta + nombre); // Permite referenciar cierto archivo para interactuar (crear,leer, modificar, etc)       
        OutputStream out = response.getOutputStream(); // Será el archivo salida: un nuevo documento
        FileInputStream in = new FileInputStream(f); // Permite leer datos orientados a bytes (flujos de bytes sin procesar) como datos de imagen, audio, video, etc
        byte[] buffer = new byte[4096];
        int length;
        // Se lee el archivo que se va a descargar 
        while ((length = in.read(buffer)) > 0) { // Permite leer bytes de datos del documento
            out.write(buffer, 0, length); // Permite escribir bytes de datos en el nuevo documento 
        }
        in.close(); //Termina de leer el archivo
        out.flush(); //Envia el archivo salida al navegador
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
